#!/bin/bash
cppython SimSelector.py
